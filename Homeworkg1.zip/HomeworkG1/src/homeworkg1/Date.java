/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homeworkg1;

import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lucia
 */
public class Date {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {

        Scanner input = new Scanner(System.in);
        String Name = "", Email = "", Dir = "";
        int Age;
        float Id;
        File Date;

        Date = new File("C:\\Users\\lucia\\Desktop\\archivos\\Informacion.txt");

        if (!Date.exists()) {

            try {
                Date.createNewFile();

                FileWriter write = new FileWriter(Date, true);
                PrintWriter line = new PrintWriter(write);

                System.out.print("Ingrese su nombre: ");
                Name = input.nextLine();
                System.out.print("Ingrese su dirección: ");
                Dir = input.nextLine();
                System.out.print("Ingrese su Email: ");
                Email = input.nextLine();
                System.out.print("Ingrese su edad : ");
                Age = input.nextInt();
                input.nextLine();
                System.out.print("Ingrese su numero carnet: ");
                Id = input.nextFloat();

                line.println("Name: " + Name);
                line.println("Dir: " + Dir);
                line.println("Email: " + Email);
                line.println("Age: " + Age);
                line.println("Id: " + Id);

                line.close();
                write.close();

            } catch (IOException ex) {
                Logger.getLogger(Date.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            try {
                FileWriter write = new FileWriter(Date, true);
                PrintWriter line = new PrintWriter(write);

                System.out.print("Ingrese su nombre: ");
                Name = input.nextLine();
                System.out.print("Ingrese su dirección: ");
                Dir = input.nextLine();
                System.out.print("Ingrese su Email: ");
                Email = input.nextLine();
                System.out.print("Ingrese su edad : ");
                Age = input.nextInt();
                input.nextLine();
                System.out.print("Ingrese su numero carnet: ");
                Id = input.nextFloat();

                line.println("Nombre: " + Name);
                line.println("Dirección: " + Dir);
                line.println("Email " + Email);
                line.println("Edad " + Age);
                line.println("Id " + Id);

                line.close();
                write.close();
                
            } catch (IOException ex) {
                Logger.getLogger(Date.class.getName()).log(Level.SEVERE, null, ex);

            }

        }
    }
}